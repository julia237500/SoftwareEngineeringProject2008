This folder contains all our sequence diagrams for Lab 2.
