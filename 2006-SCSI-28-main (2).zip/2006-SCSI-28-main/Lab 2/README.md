# DELIVERABLES For Lab 2
- Use Case Diagram
- Use Case Descriptions
- Class Diagram of entity classes
- Key boundary classes and control classes
- Sequence diagrams of some use cases
- Initial Dialog map
