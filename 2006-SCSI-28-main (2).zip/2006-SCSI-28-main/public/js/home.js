document.addEventListener("DOMContentLoaded", () => {
  window.initHomeMap = initHomeMap;
});

let homeMap;

function initHomeMap() {
  const center = { lat: 1.3521, lng: 103.8198 };

  homeMap = new google.maps.Map(document.getElementById("HOME_MAP"), {
    center,
    zoom: 12,
  });

  fetch('/EwasteRecycling.json')
    .then(response => response.json())
    .then(data => {
      const markers = [];
      data.features.forEach(feature => {
        const coords = feature.geometry.coordinates;
        const properties = feature.properties;
        const marker = new google.maps.Marker({
          position: { lat: coords[1], lng: coords[0] },
          title: properties.NAME || 'E-waste Bin',
        });
        const infoWindow = new google.maps.InfoWindow({
          content: `
          <div style="font-family: Arial, sans-serif; font-size: 14px; line-height: 1.5;">
            <h5 style="margin: 0; color: #2c3e50;">${properties.NAME || 'E-waste Bin'}</h5>
            <p style="margin: 4px 0; color: #7f8c8d;">${properties.ADDRESSSTREETNAME || 'No address available'}</p>
          </div>
        `,
        });

        marker.addListener('click', () => {
          infoWindow.open(homeMap, marker);
        });

        markers.push(marker);
      });
      new markerClusterer.MarkerClusterer({
        map: homeMap,
        markers,
      });
    })
    .catch(error => console.error('Error loading JSON:', error));
}



