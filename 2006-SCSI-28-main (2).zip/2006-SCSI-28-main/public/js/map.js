document.addEventListener("DOMContentLoaded", () => {
  window.initMapPage = initMapPage;
});

let mapPageMap;
let userMarker;
let directionsService;
let directionsRenderer;
let markers = [];
let markerCluster;

function initMapPage() {

  const defaultCenter = { lat: 1.3521, lng: 103.8198 };


  mapPageMap = new google.maps.Map(document.getElementById("MAP_PAGE"), {
    center: defaultCenter,
    zoom: 12,
  });


  directionsService = new google.maps.DirectionsService();
  directionsRenderer = new google.maps.DirectionsRenderer();
  directionsRenderer.setMap(mapPageMap);


  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const userLocation = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        };

        userMarker = new google.maps.Marker({
          position: userLocation,
          map: mapPageMap,
          title: "You are here",
          icon: {
            url: "https://maps.google.com/mapfiles/ms/icons/blue-dot.png",
          },
        });

        mapPageMap.setCenter(userLocation);
      },
      () => {
        alert("Unable to retrieve your location. Showing default location.");
      }
    );
  } else {
    alert("Geolocation is not supported by your browser. Showing default location.");
  }


  fetch("/EwasteRecycling.json")
    .then((response) => response.json())
    .then((data) => {
      data.features.forEach((feature) => {
        const coords = feature.geometry.coordinates;
        const properties = feature.properties;


        const marker = new google.maps.Marker({
          position: { lat: coords[1], lng: coords[0] },
          map: mapPageMap,
          title: properties.ADDRESSSTREETNAME || "E-waste Bin",
        });


        const infoWindow = new google.maps.InfoWindow({
          content: `
            <div style="font-family: Arial, sans-serif; font-size: 14px; line-height: 1.5;">
              <h5 style="margin: 0; color: #2c3e50;">${properties.ADDRESSSTREETNAME || "E-waste Bin"}</h5>
              <p style="margin: 4px 0; color: #7f8c8d;">${properties.DESCRIPTION || "No description available"}</p>
              <button onclick="calculateAndDisplayRoute(${coords[1]}, ${coords[0]})" style="background-color: #3498db; color: white; border: none; padding: 5px 10px; cursor: pointer;">Get Directions</button>
            </div>
          `,
        });

        marker.addListener("click", () => {
          infoWindow.open(mapPageMap, marker);
        });

        markers.push(marker);
      });


      markerCluster = new markerClusterer.MarkerClusterer({
        map: mapPageMap,
        markers,
      });
    })
    .catch((error) => console.error("Error loading JSON:", error));

  addZoomToMeControl();
}

function calculateAndDisplayRoute(lat, lng) {
  if (!userMarker) {
    alert("User location not available. Please enable location services.");
    return;
  }

  const userLocation = userMarker.getPosition();
  const destination = { lat, lng };

  directionsService.route(
    {
      origin: userLocation,
      destination: destination,
      travelMode: google.maps.TravelMode.DRIVING,
    },
    (response, status) => {
      if (status === google.maps.DirectionsStatus.OK) {
        directionsRenderer.setDirections(response);
      } else {
        alert("Directions request failed due to " + status);
      }
    }
  );
}

function searchBins() {
  const query = document.getElementById("searchBar").value.toLowerCase();

  markers.forEach((marker) => {
    const name = marker.getTitle();
    if (name && name.toLowerCase().includes(query)) {
      marker.setMap(mapPageMap);
    } else {
      marker.setMap(null);
    }
  });


  mapPageMap.setZoom(12);
  mapPageMap.setCenter({ lat: 1.3521, lng: 103.8198 });
}

function filterByDistance() {
  const distance = document.getElementById("distanceSlider").value;
  document.getElementById("distanceValue").textContent = `${distance} km`;

  if (!userMarker) {
    alert("User location not available. Please enable location services.");
    return;
  }

  const userLocation = userMarker.getPosition();


  const filteredMarkers = markers.filter((marker) => {
    const markerPosition = marker.getPosition();
    const distanceToMarker = google.maps.geometry.spherical.computeDistanceBetween(userLocation, markerPosition) / 1000; // Convert to km

    if (distanceToMarker <= distance) {
      marker.setMap(mapPageMap);
      return true;
    } else {
      marker.setMap(null);
      return false;
    }
  });


  if (markerCluster) {
    markerCluster.clearMarkers();
    markerCluster.addMarkers(filteredMarkers);
  } else {
    markerCluster = new markerClusterer.MarkerClusterer({
      map: mapPageMap,
      markers: filteredMarkers,
    });
  }
}

function addZoomToMeControl() {
  const controlDiv = document.createElement("div");
  controlDiv.style.margin = "10px";

  const zoomButton = document.createElement("button");
  zoomButton.textContent = "Zoom to Me";
  zoomButton.style.cssText = "background-color: #3498db; color: white; border: none; padding: 10px; cursor: pointer; font-size: 14px; border-radius: 4px;";

  zoomButton.addEventListener("click", () => {
    if (userMarker) {
      const userLocation = userMarker.getPosition();
      mapPageMap.setCenter(userLocation);
      mapPageMap.setZoom(15);
    } else {
      alert("User location not available. Please enable location services.");
    }
  });

  controlDiv.appendChild(zoomButton);

  mapPageMap.controls[google.maps.ControlPosition.TOP_LEFT].push(controlDiv);
}