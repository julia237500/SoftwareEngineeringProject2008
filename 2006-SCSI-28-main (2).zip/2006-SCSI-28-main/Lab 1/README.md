# Step-by step Instructions on how to view our Figma Interactive UI Mockup
1. Open https://www.figma.com/proto/MyKZDhaKCNQXJbHfucpjJt/E-Waste?node-id=0-1&p=f&t=cBDhuxkqIn5FfYlK-0&scaling=scale-down&content-scaling=fixed&page-id=0%3A1&starting-point-node-id=1%3A903 
3. Click on the buttons (Login/Sign up/FAQ/About us)
4. Each button will bring you to a different page.
5. For example, upon clicking on Login/Sign up, you will be brought to the Login page, in which you can select Forget Password/Username.



# DELIVERABLES For Lab 1
- Documentation of functional and non-functional requirements
- Data dictionary
- Initial Use Case Model, consisting of Use Case diagram and Use Case descriptions
- UI Mockups


