module.exports = {
    // Format date helper
    formatDate: function(date, format) {
        return new Date(date).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    },
    
    // Format time helper
    formatTime: function(date) {
        return new Date(date).toLocaleTimeString('en-US', {
            hour: '2-digit',
            minute: '2-digit',
            hour12: true
        });
    },
    
    // Check if date is in the past
    isPastDue: function(date) {
        return new Date(date) < new Date();
    },
    
    // Check if values are equal
    eq: function(v1, v2) {
        return v1 === v2;
    },
    
    // Not equal comparison
    ne: function(v1, v2) {
        return v1 !== v2;
    },
    
    // Greater than comparison
    gt: function(v1, v2) {
        return v1 > v2;
    },
    
    // Less than comparison
    lt: function(v1, v2) {
        return v1 < v2;
    },
    
    // Add values
    add: function(v1, v2) {
        return v1 + v2;
    },
    
    // Subtract values
    subtract: function(v1, v2) {
        return v1 - v2;
    },
    
    // Check if value is included in array
    contains: function(arr, value) {
        if (!arr) return false;
        return arr.includes(value);
    },

    // JSON stringify helper
    json: function(context) {
        return JSON.stringify(context);
    },

    // Conditional helper
    when: function(operand_1, operator, operand_2, options) {
        let operators = {
            'eq': function(l,r) { return l == r; },
            'noteq': function(l,r) { return l != r; },
            'gt': function(l,r) { return Number(l) > Number(r); },
            'lt': function(l,r) { return Number(l) < Number(r); },
            'gteq': function(l,r) { return Number(l) >= Number(r); },
            'lteq': function(l,r) { return Number(l) <= Number(r); }
        }
        let result = operators[operator](operand_1, operand_2);
        
        if (result) return options.fn(this);
        else return options.inverse(this);
    }
};
