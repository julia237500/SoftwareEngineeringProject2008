const Reminder = require('../models/Reminder');
const mongoose = require('mongoose');
const alertMessage = require('../helpers/messenger');

function showDashboard(req, res) {
  res.render('reminderDashboard', {
    user: req.session.user,
    nav: { reminder: true }
  });
}

function displayReminderForm(req, res) {
  res.render('reminderForm', {
    title: 'Create New Reminder',
    user: req.session.user
  });
}

// Submit a new reminder
async function submitReminder(req, res) {
  const { message, datetime } = req.body;

  if (!message || !datetime) {
    alertMessage(req, 'error', 'Message and date/time cannot be blank.');
    return res.redirect('/reminder/new');
  }

  try {
    const newReminder = new Reminder({
      userID: req.session.user.id,
      message,
      datetime
    });

    await newReminder.save();

    alertMessage(req, 'success', 'Reminder created successfully!');
    res.redirect('/reminder/myreminders');
  } catch (err) {
    console.error(err);
    alertMessage(req, 'error', 'There was an error creating your reminder. Please try again.');
    res.redirect('/reminder/new');
  }
}

// View all reminders of logged-in user
async function viewMyReminders(req, res) {
  try {
    const reminders = await Reminder.find({ userID: req.session.user.id }).lean();
    res.render('reminderList', { title: 'My Reminders', reminders });
  } catch (err) {
    console.error(err);
    alertMessage(req, 'error', 'There was an error retrieving your reminders. Please try again.');
    res.redirect('/reminder/reminderDashboard');
  }
}



module.exports = {
  showDashboard,
  displayReminderForm,
  submitReminder,
  viewMyReminders
};