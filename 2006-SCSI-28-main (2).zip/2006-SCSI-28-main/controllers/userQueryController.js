const Query = require('../models/Query'); //import Query model
const alertMessage = require('../helpers/messenger');

//Display the query dashboard
function showDashboard(req, res) {
  res.render('queryDashboard', {
    user: req.session.user,
    nav: { query: true }
  });
}

// Display the form to submit a new query
function displayQueryForm(req, res) {
    res.render('queryForm', { 
    title: 'Create New Query',  //title
  user: req.session.user, 
  });
}

// Submit a new query 
async function submitQuery(req,res) {   //asyn as need wait for DB
  const { question } = req.body;  //Pulls question out of request body.
  
  if (!question) {   //error handling for empty question
    alertMessage(req, 'error', 'Question cannot be blank.');
    return res.redirect('/query/new');
  }
  try {
    const newQuery = new Query({
      userID: req.session.user.id,  //get userID from session user
      question: question,
    });
    console.log("About to save:", newQuery);
    await newQuery.save();  //save to MongDB

    //success message
    alertMessage(req, 'success', 'Query created successfully!');
    // Redirect to the My Queries page
    res.redirect('/query/myqueries');
  } catch (err) {
    console.error(err);
    alertMessage(req, 'error', 'There was an error submitting your query. Please try again.');
    res.redirect('/query/new');
  }
}

// View all queries for a given user
async function viewMyQueries(req,res) {     //async as need wait for DB
  try {
  const queries = await Query.find({ userID: req.session.user.id }).lean(); //so hdl can access mongoose object directly
  res.render('queryList', { title: 'My Queries', queries });
} catch (err) {
  console.error(err);
  alertMessage(req, 'error', 'There was an error retrieving your queries. Please try again.');
  res.redirect('/query/queryDashboard');
  }
}

module.exports = {
  showDashboard,
  displayQueryForm,
  submitQuery,
  viewMyQueries
};


 