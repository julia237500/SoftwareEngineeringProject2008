const express = require('express');
const router = express.Router();
router.use((req, res, next) => {
  res.locals.nav = { map: true };
  next();
});
router.get('/', (req, res) => {
    res.render('map', { 
        title: 'Find E-Waste Bins',
        user: req.session.user ? {
            name: req.session.user.name,
            email: req.session.user.email
        } : null
    });
});

module.exports = router;