const express = require('express');
const router = express.Router();
const User = require('../models/User');
const { ensureAuthenticated, ensureGuest, ensureAdmin } = require('../middleware/auth');
const alertMessage = require('../helpers/messenger');

router.get('/login', ensureGuest, (req, res) => {
    res.render('login', { title: 'Login', nav: { login: true } });
});
router.get('/register', ensureGuest, (req, res) => {
    const registerData = req.session.registerData || {};
    delete req.session.registerData;
    
    res.render('register', { 
        title: 'Register', 
        nav: { register: true },
        name: registerData.name || '',
        username: registerData.username || '',
        email: registerData.email || ''
    });
});

// Register handle
router.post('/register', async (req, res) => {
    try {
        const { name, username, email, password, password2, adminCode } = req.body;

        // Check required fields
        if (!name || !username || !email || !password || !password2) {
            // Store form data in session to repopulate form
            req.session.registerData = { name, username, email };
            alertMessage(req, 'error', 'Please fill in all fields');
            return res.redirect('/register');
        }

        // Check username length
        if (username && username.length < 3) {
            req.session.registerData = { name, username, email };
            alertMessage(req, 'error', 'Username should be at least 3 characters');
            return res.redirect('/register');
        }

        // Check passwords match
        if (password !== password2) {
            req.session.registerData = { name, username, email };
            alertMessage(req, 'error', 'Passwords do not match');
            return res.redirect('/register');
        }

        // Check password requirements
        const passwordRegex = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,}$/;
        if (!passwordRegex.test(password)) {
            req.session.registerData = { name, username, email };
            alertMessage(req, 'error', 'Password must be at least 6 characters and contain at least 1 number and 1 special character');
            return res.redirect('/register');
        }

        // Check if email or username exists
        const existingUser = await User.findOne({
            $or: [
                { email: email },
                { username: username }
            ]
        });

        if (existingUser) {
            req.session.registerData = { name, username, email };
            if (existingUser.email === email) {
                alertMessage(req, 'error', 'Email is already registered');
            }
            if (existingUser.username === username) {
                alertMessage(req, 'error', 'Username is already taken');
            }
            return res.redirect('/register');
        }

        // Determine admin flag if adminCode provided
        let isAdmin = false;
        if (adminCode && adminCode.trim() !== '') {
            if (!process.env.ADMIN_CODE) {
                req.session.registerData = { name, username, email };
                alertMessage(req, 'error', 'Admin code is not configured on the server');
                return res.redirect('/register');
            }
            if (adminCode !== process.env.ADMIN_CODE) {
                req.session.registerData = { name, username, email };
                alertMessage(req, 'error', 'Invalid admin code');
                return res.redirect('/register');
            }
            isAdmin = true;
        }

        // Create and save the new user
        const newUser = new User({
            name,
            username,
            email,
            password,
            isAdmin
        });

        await newUser.save();
        console.log('User registered successfully:', newUser.email);
        alertMessage(req, 'success', 'You are now registered and can log in');
        return res.redirect('/login');

    } catch (err) {
        console.error('Registration error:', err);
        req.session.registerData = { 
            name: req.body.name, 
            username: req.body.username, 
            email: req.body.email 
        };
        alertMessage(req, 'error', 'An error occurred during registration. Please try again.');
        return res.redirect('/register');
    }
});

// Login handle
router.post('/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        const user = await User.findOne({ email });
        if (!user) {
            alertMessage(req, 'danger', 'That email is not registered');
            res.redirect('/login');
            return;
        }

        const isMatch = await user.matchPassword(password);
        if (!isMatch) {
            alertMessage(req, 'danger', 'Password incorrect');
            res.redirect('/login');
            return;
        }

        // Create session
        req.session.user = {
            id: user._id,
            name: user.name,
            username: user.username,
            email: user.email,
            isAdmin: user.isAdmin || false
        };
        // Clear any existing messages first
        req.session.messages = [];
        alertMessage(req, 'success', 'You are now logged in');
        res.redirect('/profile');
    } catch (err) {
        console.error(err);
        alertMessage(req, 'danger', 'Error in login');
        res.redirect('/login');
    }
});

// Admin login page
router.get('/admin/login', ensureGuest, (req, res) => {
    res.render('adminLogin', { title: 'Admin Login', nav: { login: true } });
});

// Admin login handle
router.post('/admin/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        const user = await User.findOne({ email });
        if (!user) {
            alertMessage(req, 'danger', 'That email is not registered');
            return res.redirect('/admin/login');
        }

        const isMatch = await user.matchPassword(password);
        if (!isMatch) {
            alertMessage(req, 'danger', 'Password incorrect');
            return res.redirect('/admin/login');
        }

        // Ensure user has admin flag
        if (!user.isAdmin) {
            alertMessage(req, 'danger', 'You do not have admin privileges');
            return res.redirect('/admin/login');
        }

        // Create session with admin flag
        req.session.user = {
            id: user._id,
            name: user.name,
            username: user.username,
            email: user.email,
            isAdmin: true
        };
        // Clear messages then redirect
        req.session.messages = [];
        alertMessage(req, 'success', 'You are now logged in as admin');
        res.redirect('/admin/dashboard');
    } catch (err) {
        console.error(err);
        alertMessage(req, 'danger', 'Error in admin login');
        res.redirect('/admin/login');
    }
});

// Admin dashboard (placeholder)
router.get('/admin/dashboard', ensureAuthenticated, ensureAdmin, (req, res) => {
    res.render('adminDashboard', { title: 'Admin Dashboard', nav: { admin: true }, user: req.session.user });
});

// Logout handle
router.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) console.error(err);
        res.redirect('/login');
    });
});

// Profile update handle
router.post('/profile/update', async (req, res) => {
    const { name, username } = req.body;
    const userId = req.session.user.id;

    try {
        // Check if username is taken by another user
        const existingUser = await User.findOne({ username, _id: { $ne: userId } });
        if (existingUser) {
            alertMessage(req, 'danger', 'Username is already taken');
            return res.redirect('/profile');
        }

        // Update user
        const user = await User.findById(userId);
        user.name = name;
        user.username = username;
        await user.save();

        // Update session
        req.session.user = {
            id: user._id,
            name: user.name,
            username: user.username,
            email: user.email
        };

        alertMessage(req, 'success', 'Profile updated successfully');
        res.redirect('/profile');
    } catch (err) {
        console.error(err);
        alertMessage(req, 'danger', 'Error updating profile');
        res.redirect('/profile');
    }
});

router.get('/changeCurrentPassword', ensureAuthenticated, (req, res) => {
    res.render('changeCurrentPassword', { title: 'Change Current Password', nav: { profile: true } });
});

router.post('/changeCurrentPassword', ensureAuthenticated, async (req, res) => {
    const { currentPassword, newPassword, confirmNewPassword } = req.body;
    const userId = req.session.user.id;
    const errors = [];
    
    try {
        const user = await User.findById(userId);

        // Check if current password matches
        const isMatch = await user.matchPassword(currentPassword);
        if (!isMatch) {
            errors.push({ msg: 'Current password is incorrect' });
        }

        // Check new passwords match
        if (newPassword !== confirmNewPassword) {
            errors.push({ msg: 'New passwords do not match' });
        }

        // Check new password requirements
        const passwordRegex = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,}$/;
        if (!passwordRegex.test(newPassword)) {
            errors.push({ msg: 'New password must be at least 6 characters and contain at least 1 number and 1 special character' });
        }

        if (errors.length > 0) {
            return res.render('changeCurrentPassword', {
                title: 'Change Current Password',
                nav: { profile: true },
                errors
            });
        }

        // Update password
        user.password = newPassword;
        await user.save();

        alertMessage(req, 'success', 'Password changed successfully');
        res.redirect('/profile');
    } catch (err) {
        console.error(err);
        alertMessage(req, 'danger', 'Error changing password');
        res.redirect('/changeCurrentPassword');
    }
});

module.exports = router;