const express = require('express');
const { ensureAuthenticated, ensureAdmin } = require('../middleware/auth');
const adminQueryController = require('../controllers/adminQueryController');

const router = express.Router();

router.use(ensureAuthenticated);
router.use(ensureAdmin);
//router.use((req, res, next) => {
//  res.locals.nav = res.locals.nav || {};
//  res.locals.nav.query = true;             
//  next();
//});

router.get('/Dashboard', adminQueryController.displayAdminQueryDashboard);

router.get('/Dashboard/queryList', adminQueryController.displayUserQueries); //2 status filter

router.post('/Dashboard/queryRespond/:id', adminQueryController.respondToQuery);  //each query has its own ID

module.exports = router;
