
# SC2006 - Software Engineering
# Bin Buddy - An E-waste Recycling App


| Lab Group  | SCSI                                  |
|------------|---------------------------------------|
| Team       | Group 3                               |
| Title      | Bin Buddy                             |
| Members    | HTOO MYAT NOE (U2422977K)             |
|            | ARMAN KHAN (U2421760A)                |
|            | CHUA YUE JUN (U2423015D)              |
|            | NIKHIL MADETI (U2421243D)             |
|            | SOH CEK CONG (U2423500C)              |
|            | YOONG HONG JUN, NICHOLAS (U2321582L)  |



# Our App and Target Users
Our system’s target users are E-waste disposers. With climate change being prevalent in today’s world, E-waste being frequently discarded and people wanting to engage in more environmentally friendly practices, the government has set up E-waste disposal bins all around the country. E-waste is electronic equipment of any kind that has been discarded. In 2023, Singapore produced about 60,000 tonnes of E-waste, but only 16,0000 tonnes were recycled (Strait Times, 2024). The low E-waste recycling rate is due to the lack of awareness, as many people do not know E-waste bins exist, or find it inconvenient to recycle. Our team aims to make the recycling process more convenient by making it easier for electronic users to locate recycling bins near where they work or stay.

With our web application (app), users of our app will be able to quickly locate the E-waste disposal bins near them, and be directed to the nearest ones with the highest occupancy, along with gaining access to educational guidelines, among others. We will use NEA’s dataset on E-waste disposal bins around Singapore from data.gov.sg for the development of our app. 

## Admin account setup

The application supports creating admin accounts at registration by providing a secret admin code. To enable this, set an environment variable `ADMIN_CODE` on the server.

When `ADMIN_CODE` is set, a user who provides the exact same code in the "Admin Code" field on the registration page will be created with admin privileges (`isAdmin: true`). If the code is not set or incorrect, admin creation is denied.

Example (PowerShell):
```powershell
# Windows PowerShell - set for current session
$env:ADMIN_CODE = "my-secret-admin-code"
```

For production, set `ADMIN_CODE` in your environment or deployment configuration (do NOT commit the code to source control).

